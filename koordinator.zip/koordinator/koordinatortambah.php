<?php
if (isset($_POST["tambahkoordinator"])) {
    $namakoor = $_POST["namakoor"];
    $alamat = $_POST["alamat"];
    $nokontak = $_POST["nokontak"];
    $asalfasyankes = $_POST["asalfasyankes"];

    $tambahkoordinator = mysqli_query($conn, "INSERT INTO koordinator VALUES(NULL,'$namakoor','$alamat','$nokontak','$asalfasyankes')");
    // Menjalankan statement
    if ($tambahkoordinator) {
        echo "<script>alert('Berhasil Tambah Koordinator'); window.location.href='koordinator.php';</script>";
    } else {
        echo "<script>alert('Gagal Tambah Koordinator'); window.location.href='koordinator.php';</script>";
    }
}


?>