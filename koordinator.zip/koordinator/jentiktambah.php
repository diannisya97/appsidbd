<?php

if (isset($_POST['tambahjentik'])) {
    $namapemilik = $_POST['id']; // Menggunakan id pasien
    $namakoor = $_POST['idkoordinator']; // Menggunakan id koordinator
    $tanggalrekap = $_POST['tanggalrekap'];
    $bakmandi = $_POST['bakmandi'];
    $dispenser = $_POST['dispenser'];
    $penampung = $_POST['penampung'];
    $potbunga = $_POST['potbunga'];
    $tempatminumhewan = $_POST['tempatminumhewan'];
    $banbekas = $_POST['banbekas'];
    $sampah = $_POST['sampah'];
    $pohon = $_POST['pohon'];
    $lainnya = $_POST['lainnya'];

    // Menyimpan data ke database
    $query = "INSERT INTO jentikperiksa (namapemilik, namakoor, tanggalrekap, bakmandi, dispenser, penampung, potbunga, tempatminumhewan, banbekas, sampah, pohon, lainnya) 
              VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('ssssssssssss', $namapemilik, $namakoor, $tanggalrekap, $bakmandi, $dispenser, $penampung, $potbunga, $tempatminumhewan, $banbekas, $sampah, $pohon, $lainnya);

    if ($stmt->execute()) {
        echo "<script>alert('Data berhasil ditambahkan'); window.location.href = 'jentik.php';</script>";
    } else {
        echo "<script>alert('Terjadi kesalahan: " . $stmt->error . "');</script>";
    }
    $stmt->close();
    $conn->close();
}
?>
