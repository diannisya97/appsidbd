<!-- nav.php -->
<nav class="sb-topnav navbar navbar-expand navbar-dark bg-dark">
    <!-- Navbar Logo -->
    <button class="btn btn-link btn-sm order-1 order-lg-0 me-4 me-lg-0" id="sidebarToggle" href="#"><i class="fas fa-bars"></i></button>
    <div class="navbar-brand ps-3" style="text-align: left;">
        <a href="dashboard.php">
            <img src="../travelista-master/img/logo.png" alt="Logo" class="img-fluid" style="max-width: 80%; height: auto;">
        </a>
    </div>
    
    <!-- Navbar Search -->
    <form class="d-none d-md-inline-block form-inline ms-auto me-0 me-md-3 my-2 my-md-0"></form>
    
    <!-- Navbar User Menu -->
    <ul class="navbar-nav ms-auto ms-md-0 me-3 me-lg-4">
    <li class="nav-item dropdown">
    <a class="nav-link dropdown-toggle" id="navbarDropdown" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
        <?php
        if (isset($_SESSION["username"]) && $_SESSION["username"] != "") {
            echo $_SESSION["username"];
        } else {
            echo "Username tidak tersedia";
        }
        ?>
        <i class="fas fa-user"></i>
    </a>
    <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
        <li>
            <a class="dropdown-item" href="profil.php?id=<?php echo $_SESSION['id']; ?>">
                Profil
            </a>
        </li>
        <li><hr class="dropdown-divider"></li>
        <li><a class="dropdown-item" href="logout.php">Logout</a></li>
    </ul>

</li>

</nav>
<!-- Bootstrap core JavaScript-->
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.min.js"></script>

<style>
    /* Mengatur logo tetap di kiri */
    .navbar-brand {
        margin-right: auto;
        padding-left: 15px;
    }

    /* Menghapus padding default pada elemen ul */
    .navbar-nav {
        margin-left: auto;
    }

    /* Samakan warna background dengan sidebar */
    .navbar {
        background-color: #343a40; /* Sama dengan warna sidebar */
    }
</style>
