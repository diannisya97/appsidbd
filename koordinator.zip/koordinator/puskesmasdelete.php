<?php
session_start();
require "../function.php";
require "../cek.php";

// get id
$idpuskesmas = isset($_GET['id']) ? $_GET['id'] : '';

if (empty($idpuskesmas) || !is_numeric($idpuskesmas)) {
    echo "<script>alert('ID Puskesmas tidak valid!'); window.location.href='puskesmas.php';</script>";
    exit();
}

$idpuskesmas = intval($idpuskesmas); // Ensure the id is an integer

if ($stmt = $conn->prepare("DELETE FROM puskesmas WHERE idpuskesmas = ?")) {
    $stmt->bind_param("i", $idpuskesmas);

    if ($stmt->execute()) {
        if ($stmt->affected_rows > 0) {
            echo "<script>alert('Data berhasil dihapus!'); window.location.href='puskesmas.php';</script>";
        } else {
            echo "<script>alert('Data tidak ditemukan atau tidak dapat dihapus!'); window.location.href='puskesmas.php';</script>";
        }
    } else {
        echo "DATA GAGAL DIHAPUS! Error: " . $stmt->error;
    }

    $stmt->close();
} else {
    echo "ERROR: Could not prepare query: " . $conn->error;
}

$conn->close();

?>
