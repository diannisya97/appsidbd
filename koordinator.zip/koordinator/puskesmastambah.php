<?php
// Koneksi ke dalam database
$conn = mysqli_connect("localhost", "root", "", "app-sidbd");

// Cek koneksi
if (!$conn) {
    die("Koneksi gagal: " . mysqli_connect_error());
}

// Handle the form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nama_puskesmas = mysqli_real_escape_string($conn, $_POST['Nama_Puskesmas']);
    $nomor_kontak = mysqli_real_escape_string($conn, $_POST['Nomor_Kontak']);
    $kepala_puskesmas = mysqli_real_escape_string($conn, $_POST['kepala_puskesmas']);
    $jam_operasional = mysqli_real_escape_string($conn, $_POST['jam_operasional']);
    $alamat = mysqli_real_escape_string($conn, $_POST['Alamat']);
    $longitude = mysqli_real_escape_string($conn, $_POST['longitude']);
    $latitude = mysqli_real_escape_string($conn, $_POST['latitude']);

    // Insert the new Puskesmas data into the database
    $query = "INSERT INTO puskesmas (Nama_Puskesmas, Nomor_Kontak, kepala_puskesmas, jam_operasional, Alamat, longitude, latitude)
              VALUES ('$nama_puskesmas', '$nomor_kontak', '$kepala_puskesmas', '$jam_operasional', '$alamat', '$longitude', '$latitude')";
    
    // Execute the query
    $tambahpuskesmas = mysqli_query($conn, $query);

    if($tambahpuskesmas){
        echo "<script>alert('Berhasil Tambah Puskesmas'); window.location.href='puskesmas.php';</script>";
    } else {
        echo "<script>alert('Gagal Tambah Puskesmas'); window.location.href='puskesmas.php';</script>";
    }
}
?>
