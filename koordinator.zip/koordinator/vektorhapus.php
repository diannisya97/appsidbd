<?php
session_start();
require "../function.php";
require "../cek.php";

// get id
$idpengendalian = isset($_GET['id']) ? $_GET['id'] : '';

if (empty($idpengendalian) || !is_numeric($idpengendalian)) {
    echo "<script>alert('ID Pengendalian Vektor tidak valid!'); window.location.href='vektor.php';</script>";
    exit();
}

$idpengendalian = intval($idpengendalian); // Ensure the id is an integer

if ($stmt = $conn->prepare("DELETE FROM pengendalianvektor WHERE idpengendalian = ?")) {
    $stmt->bind_param("i", $idpengendalian);

    if ($stmt->execute()) {
        if ($stmt->affected_rows > 0) {
            echo "<script>alert('Data berhasil dihapus!'); window.location.href='vektor.php';</script>";
        } else {
            echo "<script>alert('Data tidak ditemukan atau tidak dapat dihapus!'); window.location.href='vektor.php';</script>";
        }
    } else {
        echo "DATA GAGAL DIHAPUS! Error: " . $stmt->error;
    }

    $stmt->close();
} else {
    echo "ERROR: Could not prepare query: " . $conn->error;
}

$conn->close();

?>
