<footer class="py-4 bg-light mt-auto">
<div class="container-fluid px-4">
    <div class="d-flex align-items-center justify-content-between small">
        <div class="text-muted"> dikodein &copy; SIDBD Tasikmalaya <script>document.write(new Date().getFullYear())</script></div>
    </div>
</div>
</footer>