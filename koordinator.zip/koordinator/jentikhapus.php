<?php
session_start();
require "../function.php";
require "../cek.php";

// Get id from URL
$idjentik = isset($_GET['id']) ? $_GET['id'] : '';

if (empty($idjentik) || !is_numeric($idjentik)) {
    echo "<script>alert('ID jentik tidak valid!'); window.location.href='jentik.php';</script>";
    exit();
}

$idjentik = intval($idjentik); // Ensure the id is an integer

// Delete data for the given id
$query = "DELETE FROM jentikperiksa WHERE id = ?";
if ($stmt = $conn->prepare($query)) {
    $stmt->bind_param("i", $idjentik);
    if ($stmt->execute()) {
        // If deletion was successful
        echo "<script>alert('Data jentik berhasil dihapus!'); window.location.href='jentik.php';</script>";
    } else {
        // If there was an error during deletion
        echo "<script>alert('Terjadi kesalahan saat menghapus data jentik.'); window.location.href='jentik.php';</script>";
    }
    $stmt->close();
} else {
    // Error preparing the query
    echo "<script>alert('Terjadi kesalahan saat menyiapkan query.'); window.location.href='jentik.php';</script>";
}
?>
