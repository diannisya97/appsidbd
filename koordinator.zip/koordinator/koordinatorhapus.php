<?php
session_start();
require "../function.php";
require "../cek.php";

// Pastikan parameter id ada
if (isset($_GET['id']) && !empty($_GET['id'])) {
    $id = $_GET['id'];
    
    // Hapus data dari database
    $query = "DELETE FROM koordinator WHERE id = ?";
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, 'i', $id);
    
    if (mysqli_stmt_execute($stmt)) {
        // Redirect ke halaman koordinator.php setelah penghapusan berhasil
        header("Location: koordinator.php?success=1");
        exit();
    } else {
        // Jika gagal, redirect ke halaman koordinator.php dengan parameter error
        header("Location: koordinator.php?error=1");
        exit();
    }
} else {
    // Jika id tidak ada atau kosong, redirect ke halaman koordinator.php dengan parameter error
    header("Location: koordinator.php?error=1");
    exit();
}
